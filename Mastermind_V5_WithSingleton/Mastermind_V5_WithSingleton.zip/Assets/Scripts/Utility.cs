using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System;

public class Utility
{
    public static Random random = new Random();
}

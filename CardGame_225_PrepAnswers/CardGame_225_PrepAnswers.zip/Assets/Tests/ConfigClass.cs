﻿[System.Serializable]
public class Rootobject
{
    public string SceneName;
    public DealerTester dealerTester;
    
}
[System.Serializable]
public class DealerTester
{
    public int advanceBy;
    public int endDeckTest;
    public int initialCardForSum;
    public int displayCardRelPos;

}
